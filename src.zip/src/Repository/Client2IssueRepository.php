<?php

namespace App\Repository;

use App\Entity\Client2Issue;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method Client2Issue|null find($id, $lockMode = null, $lockVersion = null)
 * @method Client2Issue|null findOneBy(array $criteria, array $orderBy = null)
 * @method Client2Issue[]    findAll()
 * @method Client2Issue[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class Client2IssueRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Client2Issue::class);
    }

    // /**
    //  * @return Client2Issue[] Returns an array of Client2Issue objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('c.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Client2Issue
    {
        return $this->createQueryBuilder('c')
            ->andWhere('c.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
