<?php

namespace App\Entity;

use App\Repository\Client2IssueRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=Client2IssueRepository::class)
 */
class Client2Issue
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $client_issue_id;

    /**
     * @ORM\Column(type="integer")
     */
    private $issue_id;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getClientIssueId(): ?int
    {
        return $this->client_issue_id;
    }

    public function setClientIssueId(int $client_issue_id): self
    {
        $this->client_issue_id = $client_issue_id;

        return $this;
    }

    public function getIssueId(): ?int
    {
        return $this->issue_id;
    }

    public function setIssueId(int $issue_id): self
    {
        $this->issue_id = $issue_id;

        return $this;
    }
}
